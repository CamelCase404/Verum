from __future__ import annotations
from datetime import datetime
from enum import Enum
from typing import Literal, Optional
from pydantic import BaseModel, Field

Level = Literal["Junior", "Middle", "Senior"]

class CatalogOption(BaseModel):
    id: str
    name: str
    icon: str
    description: str

class StackOption(CatalogOption):
    languages: list[CatalogOption]

class CatalogResponse(BaseModel):
    levels: list[CatalogOption]
    stacks: list[StackOption]

class StartInterviewRequest(BaseModel):
    level: Level
    stack_id: str
    language_ids: list[str]
    job_id: str | None = None

class Turn(BaseModel):
    role: Literal["assistant", "user"]
    content: str
    seconds_spent: int = 0
    score: Optional[int] = None

class StartInterviewResponse(BaseModel):
    interview_id: str
    stage: int
    stage_name: str
    question: str
    code_snippet: Optional[str] = None

class AnswerRequest(BaseModel):
    interview_id: str
    answer: str
    seconds_spent: int = 0

class AnswerResponse(BaseModel):
    stage: int
    stage_name: str
    question: Optional[str] = None
    code_snippet: Optional[str] = None
    finished: bool = False
    rejected: bool = False
    reject_reason: Optional[str] = None

class StageScore(BaseModel):
    stage: int
    stage_name: str
    score: int = Field(ge=0, le=100)
    evidence: list[str]
    gaps: list[str]

class ReportResponse(BaseModel):
    interview_id: str
    level: Level
    stack_id: str
    language_id: str
    summary: str
    stages: list[StageScore]
    strengths: list[str]
    gaps: list[str]
    recommendation: Literal["hire", "no_hire", "insufficient_evidence"]

    competency_architecture: Optional[int] = None
    competency_code_understanding: Optional[int] = None
    competency_prompting: Optional[int] = None
    competency_adaptability: Optional[int] = None
    competency_soft_skills: Optional[int] = None

    total_score_100: Optional[int] = None
    final_grade: Optional[Literal["Junior", "Middle", "Senior", "Reject"]] = None

    rejected: bool = False
    reject_reason: Optional[str] = None

class UserRole(str, Enum):
    DEVELOPER = "developer"
    COMPANY = "company"
    ADMIN = "admin"

class UserRegister(BaseModel):
    email: str
    password: str
    role: UserRole
    full_name: str

class UserLogin(BaseModel):
    email: str
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str

class UserProfile(BaseModel):
    id: int
    email: str
    role: UserRole
    full_name: str
    skills: dict | None = None
    company_name: str | None = None
    website: str | None = None
    github_username: str | None = None
    github_stats: dict | None = None
    bio: str | None = None
    avatar_url: str | None = None
    projects: list[dict] | None = None
    job_postings: list[dict] | None = None
    project_rate: int | None = None
    expected_salary: int | None = None
    is_unlocked: bool = False
    last_test_at: datetime | None = None
    test_status: str | None = None
    interview_video_url: str | None = None
    attempts_used: int = 0
    blocked_until: datetime | None = None
    profile_views: int = 0
    top_rank: int | None = None
    # ── SaaS-модель ──
    plan: str | None = None
    verifications_left: int | None = None
    tokens: int | None = None  # None = безлимит (enterprise)
    subscription_until: datetime | None = None
    banned: bool = False


# ── Billing-схемы ──

class PlanInfo(BaseModel):
    id: str
    name: str
    price_month: int
    verifications_per_month: int | None
    tokens_per_month: int | None
    features: list[str] = Field(default_factory=list)

class PlansResponse(BaseModel):
    plans: list[PlanInfo]

class SubscribeReq(BaseModel):
    plan: str

class TopupReq(BaseModel):
    verifications: int
    amount: int | None = None

class UsageItem(BaseModel):
    id: int
    action: str
    cost: int
    candidate_id: int | None = None
    interview_id: str | None = None
    created_at: datetime

class UsageResponse(BaseModel):
    items: list[UsageItem]
    total_spent: int
    verifications_left: int | None
    plan: str | None
    subscription_until: datetime | None

class UpdateProfileReq(BaseModel):
    bio: str | None = None
    avatar_url: str | None = None
    projects: list[dict] | None = None
    job_postings: list[dict] | None = None
    project_rate: int | None = None
    expected_salary: int | None = None
    is_unlocked: bool = False
    website: str | None = None
